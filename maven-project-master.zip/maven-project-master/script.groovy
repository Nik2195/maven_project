def hello() {
    echo 'This is the message from groovy script'
    echo "######################################"
} 

return this